# WRPPR — демо-сайт

Статический сайт без сборки. Деплой: залить папку целиком в репозиторий → импортировать в Vercel
(Framework Preset: **Other**, Build Command и Output Directory оставить пустыми).

## Структура

```
index.html          вся разметка, стили и логика
assets/fonts/       Unbounded + JetBrains Mono (woff2, latin + cyrillic)
assets/img/         pN.jpg — полные, pN-t.jpg — превью для сеток
assets/video/       silhouette.mp4 (VIDEOS), info.mp4 (заглушка в INFO)
```

## Как заменить контент

- **Фото ленты/PORTRAITS** — заменить `assets/img/p0..p6.jpg` и превью `p0-t..p6-t.jpg`.
  Имена в интерфейсе — массив `PORTRAIT_NAMES` в `index.html`.
- **COVER ART** — `c0..c4.jpg` + `-t` версии, имена в `COVER_NAMES`.
- **PROJECTS** — `w0..w6.jpg` + `-t`, имена в `PROJECT_NAMES`.
- **Видео** — заменить файлы в `assets/video/`, постеры `poster.jpg` / `poster2.jpg`.

Превью (`-t`) — ширина ~520–620px, полные — 1000–1600px. Сетки грузят только превью,
полные подтягиваются в лайтбоксе.

## Настройки

- `GATE_TRAVEL` (index.html) — сколько прокрутить, чтобы зона входа на заставке выехала целиком.
- Тема запоминается в localStorage под ключом `wrppr-theme`.
- Роутинг по hash: `/#collections`, `/#covers` и т.д. — ссылки шарятся и работает кнопка «назад».

## Что осталось на продакшен

- COLLECTIONS дублирует PORTRAITS — нужен реальный контент коллекций.
- Раскладку хаос-сетки (координаты в массиве `CARDS`) стоит собрать с дизайнером под конкретные кадры.
